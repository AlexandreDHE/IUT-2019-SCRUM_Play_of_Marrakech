package event;
public interface Event
{
}