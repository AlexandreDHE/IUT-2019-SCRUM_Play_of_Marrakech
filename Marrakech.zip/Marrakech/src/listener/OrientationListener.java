package listener;
import model.Assam;

public interface OrientationListener
{
	public void orienter(Assam assam);
}