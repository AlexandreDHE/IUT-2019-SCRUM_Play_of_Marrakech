package listener;
import java.util.EventListener;

import event.AssamEvent;

public class AssamOrienter implements AssamListener
{

	public AssamOrienter()
	{

	}
	
	@Override
	public void assamMoved(AssamEvent event){

	}

	@Override
	public void assamOriented(AssamEvent event){

	}
}
