package model;

public interface DirhamManager 
{
	public void deal(Joueur player);
}