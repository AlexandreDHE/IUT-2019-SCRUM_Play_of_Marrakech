package model;
public class Couleur
{
	public static final int JOUEUR1 = 0;
	public static final int JOUEUR2 = 1;
	public static final int JOUEUR3 = 2;
	public static final int JOUEUR4 = 3;
}